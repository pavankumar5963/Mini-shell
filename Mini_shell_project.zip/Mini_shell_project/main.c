#include<stdio.h>
#include<stdio_ext.h>
#include<signal.h>
#include<sys/stat.h>
#include<sys/types.h>
#include<unistd.h>
#include<string.h>
#include<stdlib.h>
#include<sys/wait.h>
#include "mini_shell.h"

//#define DEBUG					 	// Enable and disable debug messages
//#define SIG_DEBUG 				// Enable and disable debug message

void signal_handler(int signum, siginfo_t *info, void *data)
{
	if (signum == SIGINT)
	{
		printf("\n");	
	}
	else if (signum == SIGTSTP)
	{
		printf("\r");
	}
	else if (signum == SIGCHLD)
	{
			exit_status = info->si_status;
			printf("\r");
#ifdef SIG_DEBUG
		printf("SIGCHILD is received in parent by child pid %d\n", info->si_pid);
#endif
		/*
		 * Add the sleep process to stack
		 */
	}
	else if (signum == SIGQUIT)
	{
			printf("\r");
	}
}

int main()
{
	/*
	 * Clear the terminal
	 * Print welcome message
	 * Change signal action of SIGINT, SIGTSTP, SIGQUIT, SIGCHLD
	 * Create a stack
	 * Copy default prompt to prompt_msg
	 */
	system("clear");							// Clear the screen 
	printf("\t\t--------------------------------------\n");
	printf("\t\t\tWELCOME TO MINI-SHELL\n");
	printf("\t\t\tAuthor: B. Pavan Kumar\n");
	printf("\t\t--------------------------------------\n\n\n");

	
	struct sigaction act;
	act.sa_flags = SA_SIGINFO | SA_NOCLDSTOP | SA_NOCLDWAIT;
	act.sa_sigaction = signal_handler;
	sigaction(SIGINT, &act, NULL);
	sigaction(SIGTSTP, &act, NULL);
	sigaction(SIGCHLD, &act, NULL);
	sigaction(SIGQUIT, &act, NULL);
		
	Stack *jobs = NULL;

	strcpy(prompt_msg, "msh");
	/*
	 * Start infinite loop and scan command from user
	 * Get the present working directory path and print it on stdout
	 * Split the command into array of strings
	 * Call exec_command function to execute the command given by user
	 */

	while(1)
	{
		// Get PWD and print it
		getcwd(path_str, 200);
		
		printf("%s> ", prompt_msg);

		// Get command with arguments and split them to array of strings
		char command_str[100] = {0};
		scanf("%99[^\n]", command_str);
		int command_size = strlen(command_str);
		
		/*
		 * Validate command from user 
		 */
		
		if (command_size)          					// Command length validation
		{
			char total_command[100] = {0};
			strcpy(total_command, command_str);
			
#ifdef DEBUG
			printf("total command- %s\n", command_str);
#endif
			char *com_line_arg[50] = {0};
			int index = 0;
			com_line_arg[index] = strtok(command_str, " ");
			char *temp = NULL;
			while (temp = strtok(NULL, " "))
			{
				com_line_arg[++index] = temp;
			}
#ifdef DEBUG
			printf("Command and arguments\n");
			for (int i = 0; i <= index ; i++)
			{
				printf("%s\n", com_line_arg[i]);
			}
#endif
			if (exec_commands(com_line_arg, index + 1, &jobs, total_command) == failure)
			{
				fprintf(stderr,"exec_command function failed\n");
			}
		}
		__fpurge(stdin);					// Clear input buffer before scanning next command 
	}
	return 0;
}
