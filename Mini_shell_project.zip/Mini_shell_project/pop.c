#include "stack.h"
#include<stdlib.h>

Status pop (Stack **s)
{
	if(*s)
	{
		Stack *temp;
		temp = *s;
		*s = temp->link;
		free(temp);
		if (*s)
		{
			stack_count = (*s)->count;
		}
		else
		{
			stack_count = 0;
		}
		return success;
	}
	else
	{
		return failure; // Stack is empty
	}	
}
