#include<stdio.h>
#include<stdlib.h>
#include<errno.h>
#include<unistd.h>
#include<string.h>
#include<sys/types.h>
#include<sys/stat.h>
#include<sys/wait.h>
#include<signal.h>
#include "mini_shell.h"
#include "stack.h"

//#define STOPPED_DEBUG

Status exec_commands(char *argv[], int size, Stack **jobs, char *command)
{
		/*
		 * First Check for builtin commands
		 */

		// "exit" command 
		if (strcmp(argv[0], "exit") == 0)
		{
				exit(0);
		}

		// "fg" command
		else if (strcmp(argv[0], "fg") == 0)
		{
				/*
				 * Set default action for SIGCHLD signal and then wait to collect esit status
				 * Remove pid from stack or pop operation
				 * Generate a continous signal and block parent
				 * Set old action to SIGCHLD signal
				 */
				if (*jobs)
				{
						struct sigaction new_act, old;
						memset((void *)&old, 0, sizeof(old));
						memset((void *)&new_act, 0, sizeof(new_act));
						new_act.sa_handler = SIG_DFL;
						sigaction(SIGCHLD, &new_act, &old);
						int pid = (*jobs)->pid;
						printf("%s\n", (*jobs)->command);
						if (kill(pid, SIGCONT) == -1)
						{
								perror("kill"); 
						}
						int pro_status = 0;
						if (waitpid(pid, &pro_status, 0) == -1)
						{
								if (errno == ECHILD)
									perror("waitpid");
						}
						if (WIFEXITED(pro_status))
						{
								exit_status = WEXITSTATUS(pro_status);
						}
						pop(jobs);
						sigaction(SIGCHLD, &old, NULL);
				}
				else
				{
						fprintf(stderr,"fg: current: No such job\n");
				}
		}

		// "bg" command
		else if (strcmp(argv[0], "bg") == 0)
		{
				/* 
				 * pop operation
				 * Generate a continue signal and dont block parent
				 */
				if (*jobs)
				{
						int pid = (*jobs)->pid;
						printf("[%d]\t%s\t&\n", (*jobs)->count, (*jobs)->command);
						if (kill(pid, SIGCONT) == -1)
						{
								perror("kill"); 
						}
						pop(jobs);
				}
				else
				{
						fprintf(stderr,"bg: current: No such job\n");
				}

		}

		// "mkdir" command
		else if (strcmp(argv[0], "mkdir") == 0)
		{
				if (size == 1)
				{
						fprintf(stderr, "mkdir: missing operand\n");
				}
				else
				{
						umask(0);
						for (int i = 0; i < size - 1; i++)
						{
								int ret = mkdir(argv[i + 1], 0775);
								if (ret == -1)
								{
										perror("mkdir");
										exit_status = 1;
										//return failure;
								}
								else
								{
										exit_status = ret;
								}
						}
				}
		}

		// "rmdir" command
		else if (strcmp(argv[0], "rmdir") == 0)
		{
				if (size == 1)
				{
						fprintf(stderr, "rmdir: missing operand\n");
				}
				else
				{
						for (int i = 0; i < size - 1; i++)
						{
								int ret = rmdir(argv[i + 1]);
								if (ret == -1)
								{
										perror("rmdir");
										exit_status = 1;
										//return failure;
								}
								else
								{
										exit_status = ret;
								}
						}
				}
		}

		// "cd" command
		else if (strcmp(argv[0], "cd") == 0)
		{
				if (size == 1 || (strcmp(argv[1], "~") == 0))
				{
						argv[1] = "/home/pavan";	
				}
				else if (strcmp(argv[1], "-") == 0)
				{
						if (strlen(prev_path))
						{
								//printf("%s\n", prev_path);
								int ret = chdir(prev_path);
								if (ret == -1)
								{
										perror("chdir");
										exit_status = 1;
										//return failure;
								}
								else
								{
									exit_status = ret;
									strcpy(prev_path, path_str);
								}
						}
						else
						{
								fprintf(stderr, "cd: OLDPWD not set\n");
						}
						return success;
				}
				//printf("ture %s\n", argv[1]);
				strcpy(prev_path, path_str);
				if (chdir(argv[1]) == -1)
				{
						perror("chdir");
						//return failure;
				}
		}

		// "pwd" command
		else if (strcmp(argv[0], "pwd") == 0)
		{
				char *abs_path = getcwd(NULL, 0);
				exit_status = 0;
				printf("%s\n", abs_path);
				free(abs_path);
		}

		// "jobs" command
		else if (strcmp(argv[0], "jobs") == 0)
		{
				exit_status = 0;
				peep(*jobs);
		}

		// "echo" command
		else if (strcmp(argv[0], "echo") == 0)
		{
				if (strcmp(argv[1], "$?") == 0)
				{
						printf("%d\n", exit_status);
				}
				else if (strcmp(argv[1], "$$") == 0)
				{
						printf("%d\n", getpid());
				}
				else if (strcmp(argv[1], "$SHELL") == 0)
				{
						printf("%s\n", MSH_PATH);
				}
				else 
				{
					fprintf(stderr,"Error: No option found\nusage: echo <options>\nvalid options: $?, $$, $SHELL\n");	
				}
		}

		/*
		 * Set a new name for prompt by changing PS1 name
		 */
		else if (strncmp(argv[0], "PS1", 3) == 0)
		{
			if ((argv[0][3] == '=') && (argv[0][4] != ' '))
			{
				strncpy(prompt_msg, &argv[0][4], 99);	
			}
			else
			{
				fprintf(stderr,"Error: No such command found\nusage: PS1=<new_name>\n");
			}
		}


		/*
		 * Execute External commands by calling vfork
		 * Execute Pipe command by calling vfork
		 */
		else
		{
				/*
				 * Set default action for SIGCHLD signal and then wait to collect esit status
				 * Check command is pipe command and set pipe_flag
				 * Depending on pipe_flag call excevp or n_pipe function 
				 */
				struct sigaction new_act, old;
				memset((void *)&old, 0, sizeof(old));
				memset((void *)&new_act, 0, sizeof(new_act));
				new_act.sa_handler = SIG_DFL;
				sigaction(SIGCHLD, &new_act, &old);
				
				
				int pipe_flag = 0;
				for (int i = 0; i < size; i++)
				{
						if (strcmp(argv[i], "|") == 0)
						{
								pipe_flag = 1;
								break;
						}
				}
				if (pipe_flag)				// For N pipe command
				{
						if (pipes_command(argv, size) == failure)
						{

							//fprintf(stderr, "Error: pipes_function failed\n");
						}
				}
				else
				{

						// Create a child process and execute the command
						int ch_pid = vfork();

						if (ch_pid)				// Parent Process
						{
								int ch_status = 0;
								int ret_flag = 1;
								while(ret_flag)
								{
										if (waitpid(ch_pid, &ch_status, WUNTRACED) == -1)
										{
												if (errno != EINTR)
														ret_flag = 0;
										}
										else
										{
											ret_flag = 0;
										}
								}
								if (WIFSTOPPED(ch_status))
								{
										/*
										 * Push the process pid, command name with arguments
										 */
										//printf("%s as stopped with pid %d\n", command, ch_pid);
										push(jobs, ch_pid, command);
										print_top_stack(*jobs);
#ifdef STOPPED_DEBUG
										fprintf(stderr,"%s as stopped with pid %d\n", command, ch_pid);
										//peep(*jobs);
#endif
								}
								else if (WIFEXITED(ch_status))
								{
										exit_status = WEXITSTATUS(ch_status);
								}
						}
						else					// Child Process
						{
								if (execvp(argv[0], argv) == -1)
								{
									if (errno == ENOENT)
									{
										fprintf(stderr,"%s: command not found\n", argv[0]);
										exit(127);
									}
								}
						}	
				}	
				sigaction(SIGCHLD, &old, NULL);
		}
		return success;
}
