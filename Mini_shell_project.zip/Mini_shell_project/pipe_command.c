#include<stdio.h>
#include<stdio_ext.h>
#include<unistd.h>
#include<sys/types.h>
#include<sys/wait.h>
#include<string.h>
#include<stdlib.h>
#include<errno.h>
#include "mini_shell.h"

Status pipes_command(char *argv[], int size)
{
		// Command line arguments validation
		if (size == 1)
		{
				printf("NO ARGUMENTS PASSED\nUsage:\n./a.out <1st command> <options> | <2nd command> <options>\n");
				exit_status = 2;
				return failure;
		}
		
		int index = 0, p_index = 0;
		
		/* Get the count of pipes */
		while((index < size) && argv[index])
		{
				if (strcmp(argv[index], "|") == 0)
				{
						p_index++;
				}
				index++;
		}
		int pipes_count = p_index;				// Store pipe count 
		int proc_count = pipes_count + 1;		// No. of process to be created
		int pipes_index[pipes_count];			// Store the indexof pipe in argv

		/* Get the index of pipe ("|") from command line */
		p_index = 0;
		index = 0;
		int flag = 0;

		/* Store the pipe index of command line arguments */
		while((index < size) && argv[index])
		{
				if (strcmp(argv[index], "|") == 0)
				{
						pipes_index[p_index] = index;
						if (p_index != 0 && (pipes_index[p_index] - pipes_index[p_index - 1]) == 1)
						{
							flag = 1;
						}
						p_index++;
				}
				index++;
		}
		
		/* Arguments validation */
		if ((pipes_count == 0) || flag)							// Flag to check command line argument pipe verification
		{
		  printf("Error: Invalid Arguments\nUsage:\n<1st command> <options> | <2nd command> <options>\n");
		  exit_status = 2;
		  return failure;
		}

		/* Intialize the fds array to store pipe fds */
		int **fds = calloc(pipes_count, sizeof(int *));
		for (int i = 0; i < pipes_count; i++)
		{
				fds[i] = calloc(2, sizeof(int));
		}
		/* Create pipe and call fork in loop */
		for(int i = 0; i <= pipes_count; i++)
		{
				if (i != pipes_count)
				{
						pipe(fds[i]);
				}
				pid_t ch_pid = fork();
				if (ch_pid)
				{
						/* Parent process */
						if ( (i != 0) && (i != pipes_count))			// Close the both ends of pipes those which are not needed by child process
						{
								close(fds[i - 1][0]);
								close(fds[i - 1][1]);
						}

						if (i == pipes_count)							// Close the last pipe create 
						{
								close(fds[i - 1][0]);
								close(fds[i - 1][1]);
						}
				}
				else
				{
						/* Child process */
						if(i == 0)
						{
								/* First child process */
								//printf("First child created pid %d\n", getpid());
								int temp_index = pipes_index[i];
								argv[temp_index] = NULL;
								close(fds[0][0]);
								if (dup2(fds[0][1], 1) == -1)
								{
										//printf("First child\n");
										perror("dup2");
								}
								/* Replace the child process with the first command */
								if (execvp(argv[0], &argv[0]) == -1)
								{
                                     	if (errno == ENOENT)
                                     	{
                                         	fprintf(stderr,"%s: command not found\n", argv[0]);                                        
                                         	exit(127);
                                    	}
								}
						}
						else if (i == pipes_count)
						{
								/* Last child process */
								//printf("Last child created pid %d\n", getpid());
								int temp_index = pipes_index[i - 1] + 1;
								close(fds[i - 1][1]);
								if (dup2(fds[i - 1][0], 0) == -1)
								{
										printf("Last child\n");
										perror("dup2");
								}
								/* Repalce the last child process with last command */
								if (execvp(argv[temp_index], &argv[temp_index]) == -1)
								{
                                     	if (errno == ENOENT)
                                     	{
                                         	fprintf(stderr,"%s: command not found\n", argv[0]);                                        
                                         	exit(127);
                                    	}
								}
						}
						else
						{
								/* Intermediate child process */
								//printf("Intermediate child created pid %d\n", getpid());
								close(fds[i - 1][1]);
								close(fds[i][0]);
								if (dup2(fds[i - 1][0], 0) == -1)
								{
										printf("Intermediate child pid %d\n", getpid());
										perror("dup2");
								}
								if (dup2(fds[i][1], 1) == -1)
								{
										printf("Intermediate child pid %d\n", getpid());
										perror("dup2");
								}
								int start_index = pipes_index[i - 1] + 1;
								int end_index = pipes_index[i];
								argv[end_index] = NULL;
								if (execvp(argv[start_index], &argv[start_index]) == -1)
								{
                                     	if (errno == ENOENT)
                                     	{
                                         	fprintf(stderr,"%s: command not found\n", argv[0]);                                        
                                         	exit(127);
                                    	}
								}
						}
				}
		}
		for (int i = 0; i <= pipes_count; i++)
		{
				pid_t ter_ch;
				int status;
				ter_ch = wait(&status);
				if (WIFEXITED(status))
				{
						exit_status = WEXITSTATUS(status);
				}
				else
				{
						printf("Child %d abmormally terminated\n", ter_ch);
				}
		}
		for (int i = 0; i < pipes_count; i++)
		{
				free(fds[i]);
		}
		free(fds);
		return success;
}
