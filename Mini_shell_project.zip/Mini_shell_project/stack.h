#ifndef STACK_H
#define STACK_H

#include<stdio.h>

 int stack_count;     	// Count that stores the no. of stack  elements

/*
 * Stuctures declaration
 */

typedef enum
{
	success,
	failure,
	not_found
} Status;

/*
 * Structure model to store jobs in stack
 */
typedef struct node
{
	int pid;
	int count;
	char command[50];
	struct node *link;
} Stack;

/* Add the data to stack */
Status push (Stack **s, int pid, char *command);

/* Remove a last input data */
Status pop (Stack **s);

/* return pid of top stack */
int peek (Stack *s);

/* Print the all data in stack */
Status peep (Stack *s);

/* Print the details of top stack data */
Status print_top_stack(Stack *s);
#endif
