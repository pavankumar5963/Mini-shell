#ifndef MINI_SHELL
#define MINI_SHELL

#include "stack.h"

/* 
 * Macro defination
 */
#define MSH_PATH "/home/pavan/ECEP/Linux_Internals/Project/Mini_shell"

/*
 * Global variables
 */

char prompt_msg[100];
int exit_status;						// To store the exit status of child process
char path_str[200], prev_path[200];		// To store the current path and previous path



/* 
 *  Function prototype
 */

/* Function to excute internal and external command */
Status exec_commands(char *argv[], int size, Stack **jobs, char *command);

/* Function to excute pipes command */
Status pipes_command(char *argv[], int size);

#endif
