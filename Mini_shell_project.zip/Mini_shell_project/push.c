#include<stdlib.h>
#include "stack.h"
#include <string.h>
/* Function defination */

Status push (Stack **s, int pid, char *command)
{
	Stack *new;
	new = (Stack *) malloc(sizeof(Stack));
	new->pid = pid;
	strcpy(new->command, command);

	if (new)	// Validation of new node memory
	{
		if (*s)		// If *s is not null pointer
		{
			new->count = (*s)->count + 1;
			new->link = *s;
			*s = new;
		}
		else
		{
			new->count = 1;
			*s = new;
			new->link = NULL;
		}
		stack_count = new->count;
	}
	else
	{
		printf("Error: Memory not available\n");
		return failure;
	}
	return success;
}
