#include "stack.h"

Status print_top_stack(Stack *s)
{
		if (s)
		{
				if(s->count == stack_count)
				{
						printf("[%d]+\tStopped\t\t%s\n", s->count, s->command);
				}
				else if (s->count == (stack_count - 1))
				{
						printf("[%d]-\tStopped\t\t%s\n", s->count, s->command);
				}
				else
				{
						printf("[%d]\tStopped\t\t%s\n", s->count, s->command);
				}
				return success;
		}
		else
		{
				return failure;	
		}
}
Status peep (Stack *s)
{
		if(s)
		{
				peep(s->link);
				print_top_stack(s);	
				return success;
		}
		else
		{
				return failure;
		}
}
