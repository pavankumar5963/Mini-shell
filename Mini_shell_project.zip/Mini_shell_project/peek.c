#include "stack.h"

int peek (Stack *s)
{
	return s->pid;
}
